<?php
define('IN_STUDENT', true);
session_start();
if (empty($_SESSION['student_id'])) { header('Location: login.php'); exit; }
require_once __DIR__ . '/includes/config.php';
$page_title = 'My Profile';
$sid = (int)$_SESSION['student_id'];

$success = $error = '';

// Update profile
if (isset($_POST['update_profile'])) {
    $full_name  = trim($_POST['full_name'] ?? '');
    $phone      = trim($_POST['phone'] ?? '');
    $department = trim($_POST['department'] ?? '');
    $dbh->prepare("UPDATE tbl_students SET full_name=:n, phone=:p, department=:d WHERE id=:id")
        ->execute([':n'=>$full_name,':p'=>$phone,':d'=>$department,':id'=>$sid]);
    $_SESSION['student_name'] = $full_name;
    $success = 'Profile updated successfully.';
}

// Change password
if (isset($_POST['change_password'])) {
    $current  = $_POST['current_password'] ?? '';
    $new_pass = $_POST['new_password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    $stmt = $dbh->prepare("SELECT password FROM tbl_students WHERE id=:id");
    $stmt->execute([':id'=>$sid]);
    $row = $stmt->fetch();

    if (!password_verify($current, $row->password)) {
        $error = 'Current password is incorrect.';
    } elseif ($new_pass !== $confirm) {
        $error = 'New passwords do not match.';
    } elseif (strlen($new_pass) < 6) {
        $error = 'Password must be at least 6 characters.';
    } else {
        $hashed = password_hash($new_pass, PASSWORD_DEFAULT);
        $dbh->prepare("UPDATE tbl_students SET password=:p WHERE id=:id")->execute([':p'=>$hashed,':id'=>$sid]);
        $success = 'Password changed successfully.';
    }
}

$stmt = $dbh->prepare("SELECT * FROM tbl_students WHERE id=:id");
$stmt->execute([':id'=>$sid]);
$student = $stmt->fetch();

// Stats
$totalIssued = $dbh->prepare("SELECT COUNT(*) FROM tbl_issues WHERE student_id=:id");
$totalIssued->execute([':id'=>$sid]);
$totalIssued = $totalIssued->fetchColumn();

$ebookReads = $dbh->prepare("SELECT COUNT(*) FROM tbl_ebook_log WHERE student_id=:id AND action='read'");
$ebookReads->execute([':id'=>$sid]);
$ebookReads = $ebookReads->fetchColumn();

$ebookDownloads = $dbh->prepare("SELECT COUNT(*) FROM tbl_ebook_log WHERE student_id=:id AND action='download'");
$ebookDownloads->execute([':id'=>$sid]);
$ebookDownloads = $ebookDownloads->fetchColumn();
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="page-title"><h2>My Profile</h2><p>View and update your account details</p></div>

<?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>
<?php if ($error):   ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="row">
    <!-- LEFT: Profile info -->
    <div class="col-6" style="max-width:340px;">
        <div class="el-card" style="margin-bottom:20px;">
            <div class="el-card-header">👤 Account Info</div>
            <div class="el-card-body" style="text-align:center;">
                <div style="width:88px;height:88px;border-radius:50%;background:var(--accent-soft);display:inline-flex;align-items:center;justify-content:center;font-size:40px;margin-bottom:12px;">👤</div>
                <div style="font-family:'Playfair Display',serif;font-size:18px;color:#4b2c5e;"><?= htmlspecialchars($student->full_name) ?></div>
                <div style="font-size:13px;color:#7a6b8a;margin-bottom:16px;"><?= htmlspecialchars($student->student_id) ?></div>
                <table style="width:100%;font-size:13px;text-align:left;">
                    <tr><td style="color:#7a6b8a;padding:5px 0;">Email</td><td><?= htmlspecialchars($student->email) ?></td></tr>
                    <tr><td style="color:#7a6b8a;padding:5px 0;">Phone</td><td><?= htmlspecialchars($student->phone ?: '—') ?></td></tr>
                    <tr><td style="color:#7a6b8a;padding:5px 0;">Department</td><td><?= htmlspecialchars($student->department ?: '—') ?></td></tr>
                    <tr><td style="color:#7a6b8a;padding:5px 0;">Member Since</td><td><?= date('d M Y', strtotime($student->created_at)) ?></td></tr>
                </table>
            </div>
        </div>

        <!-- Activity Stats -->
        <div class="el-card">
            <div class="el-card-header">📊 My Activity</div>
            <div class="el-card-body">
                <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;text-align:center;">
                    <div style="padding:12px;background:#f5f0fa;border-radius:8px;">
                        <div style="font-size:22px;font-weight:700;color:#4b2c5e;"><?= $totalIssued ?></div>
                        <div style="font-size:11px;color:#7a6b8a;">Books Issued</div>
                    </div>
                    <div style="padding:12px;background:#d5f5e3;border-radius:8px;">
                        <div style="font-size:22px;font-weight:700;color:#1e8449;"><?= $ebookReads ?></div>
                        <div style="font-size:11px;color:#7a6b8a;">E-Books Read</div>
                    </div>
                    <div style="padding:12px;background:#d6eaf8;border-radius:8px;">
                        <div style="font-size:22px;font-weight:700;color:#2471a3;"><?= $ebookDownloads ?></div>
                        <div style="font-size:11px;color:#7a6b8a;">Downloads</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- RIGHT: Edit forms -->
    <div class="col-6" style="flex:1;">
        <div class="el-card" style="margin-bottom:20px;">
            <div class="el-card-header">✏️ Update Profile</div>
            <div class="el-card-body">
                <form method="POST">
                    <div class="form-group">
                        <label class="form-label">Full Name</label>
                        <input type="text" name="full_name" class="form-control" value="<?= htmlspecialchars($student->full_name) ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Phone Number</label>
                        <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($student->phone ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Department</label>
                        <input type="text" name="department" class="form-control" value="<?= htmlspecialchars($student->department ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" value="<?= htmlspecialchars($student->email) ?>" disabled style="background:#f5f0fa;cursor:not-allowed;">
                        <small class="text-muted">Email cannot be changed. Contact admin if needed.</small>
                    </div>
                    <button type="submit" name="update_profile" class="btn btn-primary">💾 Save Profile</button>
                </form>
            </div>
        </div>

        <div class="el-card">
            <div class="el-card-header">🔒 Change Password</div>
            <div class="el-card-body">
                <form method="POST">
                    <div class="form-group">
                        <label class="form-label">Current Password</label>
                        <input type="password" name="current_password" class="form-control" placeholder="Your current password" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">New Password</label>
                        <input type="password" name="new_password" class="form-control" placeholder="At least 6 characters" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Confirm New Password</label>
                        <input type="password" name="confirm_password" class="form-control" placeholder="Repeat new password" required>
                    </div>
                    <button type="submit" name="change_password" class="btn btn-warning">🔒 Change Password</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
