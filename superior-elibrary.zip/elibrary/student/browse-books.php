<?php
define('IN_STUDENT', true);
session_start();
if (empty($_SESSION['student_id'])) { header('Location: login.php'); exit; }
require_once __DIR__ . '/includes/config.php';
$page_title = 'Browse Books';
$sid = (int)$_SESSION['student_id'];

// Book detail view
$viewBook = null;
if (isset($_GET['view'])) {
    $stmt = $dbh->prepare("
        SELECT b.*, a.author_name, c.category_name
        FROM tbl_books b
        LEFT JOIN tbl_authors a ON a.id = b.author_id
        LEFT JOIN tbl_categories c ON c.id = b.category_id
        WHERE b.id = :id AND b.status = 1
    ");
    $stmt->execute([':id' => (int)$_GET['view']]);
    $viewBook = $stmt->fetch();
}

$search    = trim($_GET['s'] ?? '');
$catFilter = (int)($_GET['cat'] ?? 0);

$sql = "
    SELECT b.*, a.author_name, c.category_name
    FROM tbl_books b
    LEFT JOIN tbl_authors a ON a.id = b.author_id
    LEFT JOIN tbl_categories c ON c.id = b.category_id
    WHERE b.status = 1
";
$params = [];
if ($search) {
    $sql .= " AND (b.book_name LIKE :s OR a.author_name LIKE :s2 OR b.isbn LIKE :s3)";
    $params = [':s' => "%$search%", ':s2' => "%$search%", ':s3' => "%$search%"];
}
if ($catFilter) {
    $sql .= " AND b.category_id = :cat";
    $params[':cat'] = $catFilter;
}
$sql .= " ORDER BY b.id DESC";
$stmt = $dbh->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll();

$categories = $dbh->query("SELECT * FROM tbl_categories WHERE status=1 ORDER BY category_name")->fetchAll();
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="page-title"><h2>Browse Books</h2><p>Search the complete library catalogue</p></div>

<?php if (isset($_GET['error'])): ?>
<div class="alert alert-warning">
    <?php
    $msgs = [
        'nofile'    => '⚠️ The e-book file is not available yet. Ask the admin to upload the PDF.',
        'notfound'  => '⚠️ Book not found.',
    ];
    echo $msgs[$_GET['error']] ?? '⚠️ An error occurred.';
    ?>
</div>
<?php endif; ?>

<!-- SEARCH & FILTER -->
<div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:16px;align-items:flex-start;">
    <form method="GET" style="display:flex;gap:8px;flex:1;min-width:240px;">
        <input type="text" name="s" class="form-control" placeholder="Search by title, author or ISBN..." value="<?= htmlspecialchars($search) ?>" style="flex:1;">
        <?php if ($catFilter): ?><input type="hidden" name="cat" value="<?= $catFilter ?>"><?php endif; ?>
        <button type="submit" class="btn btn-primary">Search</button>
        <?php if ($search || $catFilter): ?>
        <a href="browse-books.php" class="btn btn-secondary">Clear</a>
        <?php endif; ?>
    </form>
</div>

<!-- CATEGORY PILLS -->
<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:16px;">
    <a href="browse-books.php<?= $search ? '?s='.urlencode($search) : '' ?>" class="btn <?= !$catFilter ? 'btn-primary' : 'btn-secondary' ?>" style="font-size:12px;padding:6px 12px;">All</a>
    <?php foreach ($categories as $c): ?>
    <a href="?cat=<?= $c->id ?><?= $search ? '&s='.urlencode($search) : '' ?>" class="btn <?= $catFilter == $c->id ? 'btn-primary' : 'btn-secondary' ?>" style="font-size:12px;padding:6px 12px;">
        <?= htmlspecialchars($c->category_name) ?>
    </a>
    <?php endforeach; ?>
</div>

<div style="font-size:13px;color:#7a6b8a;margin-bottom:16px;"><?= count($books) ?> book(s) found</div>

<!-- BOOKS GRID -->
<div class="books-grid">
    <?php if ($books): ?>
    <?php foreach ($books as $b): ?>
    <div class="book-card">
        <!-- Cover -->
        <?php
        $imgFile = $b->book_image ?? '';
        $imgPath = dirname(__DIR__) . '/admin/bookimg/' . $imgFile;
        $hasImg  = $imgFile && file_exists($imgPath);
        ?>
        <?php if ($hasImg): ?>
        <img src="../admin/bookimg/<?= htmlspecialchars($imgFile) ?>" style="height:200px;object-fit:cover;width:100%;">
        <?php else: ?>
        <div style="height:200px;background:linear-gradient(135deg,#e8d5f5,#d5c6e8);display:flex;align-items:center;justify-content:center;font-size:56px;">📗</div>
        <?php endif; ?>

        <div class="book-body">
            <div class="book-title"><?= htmlspecialchars($b->book_name) ?></div>
            <div class="book-author" style="margin-top:3px;">✍️ <?= htmlspecialchars($b->author_name ?? 'Unknown') ?></div>
            <div class="book-author" style="margin-top:2px;">🏷️ <?= htmlspecialchars($b->category_name ?? '') ?></div>
            <div style="display:flex;align-items:center;justify-content:space-between;margin-top:8px;">
                <?php if ($b->available_qty > 0): ?>
                <span class="badge badge-success">📦 <?= $b->available_qty ?> physical copies</span>
                <?php else: ?>
                <span class="badge badge-warning">📦 No physical copies</span>
                <?php endif; ?>
                <?php if ($b->ebook_file): ?>
                <span class="badge badge-info">📄 E-Book</span>
                <?php endif; ?>
            </div>
        </div>

        <div class="book-actions" style="flex-wrap:wrap;gap:5px;">
            <a href="?view=<?= $b->id ?>" class="btn btn-primary btn-sm" style="font-size:11px;">📋 Details</a>
            <?php if ($b->ebook_file): ?>
            <a href="read-book.php?id=<?= $b->id ?>" class="btn btn-success btn-sm" style="font-size:11px;">📖 Read</a>
            <a href="serve-pdf.php?id=<?= $b->id ?>&download=1" class="btn btn-info btn-sm" style="font-size:11px;">📥 PDF</a>
            <?php else: ?>
            <span style="font-size:11px;color:#7a6b8a;padding:4px 0;">No e-book</span>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>
    <?php else: ?>
    <div class="no-data" style="grid-column:1/-1;padding:60px;">
        📭 No books found matching your search.<br>
        <a href="browse-books.php" style="margin-top:10px;display:inline-block;">Clear search</a>
    </div>
    <?php endif; ?>
</div>

<!-- BOOK DETAIL MODAL -->
<?php if ($viewBook): ?>
<div style="position:fixed;inset:0;background:rgba(0,0,0,0.65);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;" onclick="if(event.target===this) window.location='browse-books.php';">
    <div style="background:white;border-radius:16px;max-width:620px;width:100%;max-height:90vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,0.4);">

        <!-- Modal Header -->
        <div style="background:#4b2c5e;color:white;padding:16px 20px;border-radius:16px 16px 0 0;display:flex;justify-content:space-between;align-items:center;">
            <span style="font-family:'Playfair Display',serif;font-size:16px;">Book Details</span>
            <a href="browse-books.php" style="color:white;font-size:20px;text-decoration:none;line-height:1;">×</a>
        </div>

        <div style="display:flex;gap:24px;padding:24px;flex-wrap:wrap;">
            <!-- Cover -->
            <div style="flex-shrink:0;">
                <?php
                $vi = $viewBook->book_image ?? '';
                $vp = dirname(__DIR__) . '/admin/bookimg/' . $vi;
                ?>
                <?php if ($vi && file_exists($vp)): ?>
                <img src="../admin/bookimg/<?= htmlspecialchars($vi) ?>" style="width:140px;height:190px;object-fit:cover;border-radius:10px;box-shadow:0 4px 16px rgba(0,0,0,0.2);">
                <?php else: ?>
                <div style="width:140px;height:190px;background:linear-gradient(135deg,#e8d5f5,#d5c6e8);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:60px;box-shadow:0 4px 16px rgba(0,0,0,0.1);">📗</div>
                <?php endif; ?>
            </div>

            <!-- Info -->
            <div style="flex:1;min-width:200px;">
                <h3 style="font-family:'Playfair Display',serif;font-size:19px;color:#4b2c5e;margin-bottom:4px;"><?= htmlspecialchars($viewBook->book_name) ?></h3>
                <p style="color:#7a6b8a;font-size:13px;margin-bottom:16px;">by <strong><?= htmlspecialchars($viewBook->author_name ?? 'Unknown') ?></strong></p>

                <table style="font-size:13px;width:100%;border-collapse:collapse;">
                    <?php
                    $rows = [
                        'Category'  => htmlspecialchars($viewBook->category_name ?? '—'),
                        'ISBN'      => htmlspecialchars($viewBook->isbn),
                        'Physical Copies' => $viewBook->available_qty > 0
                            ? '<span class="badge badge-success">' . $viewBook->available_qty . ' available to borrow</span>'
                            : '<span class="badge badge-warning">No physical copies available</span>',
                        'E-Book'    => $viewBook->ebook_file
                            ? '<span class="badge badge-info">✅ PDF Available</span>'
                            : '<span class="badge badge-warning">Not Available</span>',
                    ];
                    foreach ($rows as $label => $val):
                    ?>
                    <tr>
                        <td style="color:#7a6b8a;padding:6px 0;width:90px;vertical-align:top;"><?= $label ?></td>
                        <td style="padding:6px 0;"><?= $val ?></td>
                    </tr>
                    <?php endforeach; ?>
                </table>

                <?php if ($viewBook->description): ?>
                <div style="margin-top:14px;padding:12px;background:#f5f0fa;border-radius:8px;font-size:13px;color:#555;line-height:1.6;">
                    <?= nl2br(htmlspecialchars($viewBook->description)) ?>
                </div>
                <?php endif; ?>

                <!-- Action Buttons -->
                <div style="display:flex;gap:8px;margin-top:18px;flex-wrap:wrap;">
                    <?php if ($viewBook->ebook_file): ?>
                    <a href="read-book.php?id=<?= $viewBook->id ?>" class="btn btn-success">📖 Read Online</a>
                    <a href="serve-pdf.php?id=<?= $viewBook->id ?>&download=1" class="btn btn-info">📥 Download PDF</a>
                    <?php else: ?>
                    <div style="padding:10px;background:#fef0d9;border-radius:8px;font-size:13px;color:#935116;width:100%;">
                        📄 No e-book available for this title. To borrow a physical copy, visit the library desk.
                    </div>
                    <?php endif; ?>
                    <a href="browse-books.php" class="btn btn-secondary">Close</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
