<?php
define('IN_STUDENT', true);
session_start();
if (empty($_SESSION['student_id'])) { header('Location: login.php'); exit; }
require_once __DIR__ . '/includes/config.php';
$sid = (int)$_SESSION['student_id'];

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: browse-books.php'); exit; }

$stmt = $dbh->prepare("
    SELECT b.*, a.author_name, c.category_name
    FROM tbl_books b
    LEFT JOIN tbl_authors a ON a.id = b.author_id
    LEFT JOIN tbl_categories c ON c.id = b.category_id
    WHERE b.id = :id AND b.status = 1
");
$stmt->execute([':id' => $id]);
$book = $stmt->fetch();

if (!$book) { header('Location: browse-books.php?error=notfound'); exit; }
if (!$book->ebook_file) { header('Location: browse-books.php?error=nofile'); exit; }

$serverPath = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'ebooks' . DIRECTORY_SEPARATOR . $book->ebook_file;
if (!file_exists($serverPath)) { header('Location: browse-books.php?error=nofile'); exit; }

// Log read action
$log = $dbh->prepare("INSERT INTO tbl_ebook_log (book_id, student_id, action) VALUES (:bid, :sid, 'read')");
$log->execute([':bid' => $id, ':sid' => $sid]);

$pdfUrl  = 'serve-pdf.php?id=' . $id;
$dlUrl   = 'serve-pdf.php?id=' . $id . '&download=1';
$safeName = htmlspecialchars($book->book_name);
$author   = htmlspecialchars($book->author_name ?? 'Unknown');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reading: <?= $safeName ?> — Superior E-Library</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        * { box-sizing: border-box; }
        body { margin: 0; display: flex; flex-direction: column; height: 100vh; background: #1a1a2e; font-family: 'DM Sans', sans-serif; }

        .reader-topbar {
            background: #4b2c5e;
            color: white;
            padding: 0 20px;
            height: 56px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-shrink: 0;
            box-shadow: 0 2px 12px rgba(0,0,0,0.4);
            gap: 12px;
        }

        .reader-topbar .book-meta {
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 0;
        }

        .reader-topbar .book-meta .logo {
            height: 34px;
            background: white;
            border-radius: 6px;
            padding: 3px;
            flex-shrink: 0;
        }

        .reader-topbar .book-title {
            font-family: 'Playfair Display', serif;
            font-size: 15px;
            font-weight: 700;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 400px;
        }

        .reader-topbar .book-author {
            font-size: 12px;
            opacity: 0.7;
        }

        .reader-topbar .reader-actions {
            display: flex;
            gap: 8px;
            flex-shrink: 0;
        }

        .reader-actions a, .reader-actions button {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 7px 14px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            border: none;
            text-decoration: none;
            transition: 0.2s;
        }

        .btn-dl    { background: #27ae60; color: white; }
        .btn-dl:hover   { background: #219a52; color: white; }
        .btn-back  { background: rgba(255,255,255,0.15); color: white; border: 1px solid rgba(255,255,255,0.3); }
        .btn-back:hover { background: rgba(255,255,255,0.25); color: white; }

        /* PDF viewer area */
        .viewer-area {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        /* Tab bar */
        .viewer-tabs {
            display: flex;
            background: #2c1a3e;
            gap: 2px;
            padding: 6px 12px 0;
        }

        .viewer-tab {
            padding: 7px 16px;
            border-radius: 6px 6px 0 0;
            font-size: 12px;
            color: rgba(255,255,255,0.6);
            cursor: pointer;
            transition: 0.2s;
            border: none;
            background: transparent;
        }

        .viewer-tab.active {
            background: #f5f0fa;
            color: #4b2c5e;
            font-weight: 600;
        }

        /* Panels */
        .viewer-panels {
            flex: 1;
            background: #f5f0fa;
            overflow: hidden;
        }

        .viewer-panel { display: none; height: 100%; }
        .viewer-panel.active { display: flex; flex-direction: column; height: 100%; }

        /* Embedded iframe viewer */
        #panel-browser iframe {
            flex: 1;
            border: none;
            width: 100%;
            height: 100%;
        }

        /* JS-based canvas viewer */
        #panel-viewer {
            align-items: center;
            justify-content: flex-start;
            overflow-y: auto;
            padding: 20px;
            background: #e0e0e0;
        }

        #pdf-canvas-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 12px;
        }

        .pdf-page-canvas {
            box-shadow: 0 4px 20px rgba(0,0,0,0.25);
            max-width: 100%;
            background: white;
        }

        .viewer-controls {
            background: #2c1a3e;
            padding: 8px 16px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: white;
            font-size: 13px;
            flex-shrink: 0;
        }

        .viewer-controls button {
            background: rgba(255,255,255,0.15);
            border: 1px solid rgba(255,255,255,0.25);
            color: white;
            padding: 5px 12px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 12px;
            transition: 0.2s;
        }

        .viewer-controls button:hover { background: rgba(255,255,255,0.3); }
        .viewer-controls button:disabled { opacity: 0.4; cursor: not-allowed; }

        #page-info { font-size: 13px; color: rgba(255,255,255,0.8); }

        .zoom-controls { display: flex; gap: 5px; align-items: center; }

        /* Loading state */
        #pdf-loading {
            text-align: center;
            padding: 60px 20px;
            color: #4b2c5e;
        }
        #pdf-loading .spinner {
            width: 48px; height: 48px;
            border: 4px solid #e8d5f5;
            border-top-color: #4b2c5e;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
            margin: 0 auto 16px;
        }
        @keyframes spin { to { transform: rotate(360deg); } }

        #pdf-error {
            display: none;
            text-align: center;
            padding: 40px 20px;
            color: #c0392b;
        }
    </style>
</head>
<body>

<!-- TOP BAR -->
<div class="reader-topbar">
    <div class="book-meta">
        <img src="../assets/img/logo.png" class="logo" alt="Logo">
        <div>
            <div class="book-title">📖 <?= $safeName ?></div>
            <div class="book-author">by <?= $author ?></div>
        </div>
    </div>
    <div class="reader-actions">
        <a href="<?= $dlUrl ?>" class="btn-dl">📥 Download PDF</a>
        <a href="browse-books.php" class="btn-back">← Back</a>
    </div>
</div>

<!-- TAB BAR -->
<div class="viewer-tabs">
    <button class="viewer-tab active" onclick="switchTab('viewer')" id="tab-viewer">📖 PDF Viewer</button>
    <button class="viewer-tab" onclick="switchTab('browser')" id="tab-browser">🌐 Browser View</button>
</div>

<!-- VIEWER AREA -->
<div class="viewer-area">
    <div class="viewer-panels">

        <!-- PDF.JS CANVAS VIEWER -->
        <div id="panel-viewer" class="viewer-panel active">
            <!-- Controls -->
            <div class="viewer-controls" id="viewer-controls" style="display:none;">
                <button id="btn-prev" onclick="changePage(-1)" disabled>◀ Prev</button>
                <span id="page-info">Page 1 of 1</span>
                <button id="btn-next" onclick="changePage(1)">Next ▶</button>
                <div class="zoom-controls">
                    <button onclick="changeZoom(-0.2)">🔍−</button>
                    <span id="zoom-level" style="font-size:12px;color:rgba(255,255,255,0.7);">100%</span>
                    <button onclick="changeZoom(0.2)">🔍+</button>
                    <button onclick="changeZoom(0, true)">Fit</button>
                </div>
                <span style="flex:1;"></span>
                <span style="font-size:11px;opacity:0.6;">Scroll down to read all pages</span>
            </div>

            <div id="pdf-loading">
                <div class="spinner"></div>
                <div style="font-size:15px;font-weight:600;color:#4b2c5e;">Loading PDF...</div>
                <div style="font-size:13px;color:#7a6b8a;margin-top:6px;">Please wait while the book loads</div>
            </div>

            <div id="pdf-error">
                <div style="font-size:40px;margin-bottom:12px;">⚠️</div>
                <div style="font-size:16px;font-weight:600;">Could not load PDF viewer</div>
                <p style="font-size:13px;color:#666;margin:10px 0 20px;">Try the Browser View tab, or download the PDF directly.</p>
                <a href="<?= $dlUrl ?>" style="background:#27ae60;color:white;padding:10px 24px;border-radius:8px;text-decoration:none;font-weight:600;">📥 Download PDF Instead</a>
            </div>

            <div id="pdf-canvas-container"></div>
        </div>

        <!-- IFRAME BROWSER VIEW (fallback) -->
        <div id="panel-browser" class="viewer-panel" style="display:none;">
            <iframe src="<?= $pdfUrl ?>#toolbar=1&navpanes=1&scrollbar=1&view=FitH" title="PDF Reader"></iframe>
        </div>

    </div>
</div>

<!-- PDF.JS from CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"></script>
<script>
const PDF_URL = '<?= $pdfUrl ?>';
let pdfDoc = null, currentPage = 1, totalPages = 0, scale = 1.2, isRendering = false, renderQueue = null;

pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';

function switchTab(tab) {
    document.querySelectorAll('.viewer-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.viewer-panel').forEach(p => { p.classList.remove('active'); p.style.display='none'; });
    document.getElementById('tab-' + tab).classList.add('active');
    document.getElementById('panel-' + tab).classList.add('active');
    document.getElementById('panel-' + tab).style.display = 'flex';
}

async function loadPDF() {
    try {
        const loadingTask = pdfjsLib.getDocument(PDF_URL);
        pdfDoc = await loadingTask.promise;
        totalPages = pdfDoc.numPages;

        document.getElementById('pdf-loading').style.display = 'none';
        document.getElementById('viewer-controls').style.display = 'flex';
        document.getElementById('page-info').textContent = 'Page 1 of ' + totalPages;

        // Render all pages
        await renderAllPages();

    } catch (err) {
        console.error('PDF load error:', err);
        document.getElementById('pdf-loading').style.display = 'none';
        document.getElementById('pdf-error').style.display = 'block';
    }
}

async function renderAllPages() {
    const container = document.getElementById('pdf-canvas-container');
    container.innerHTML = '';

    for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
        const page = await pdfDoc.getPage(pageNum);
        const viewport = page.getViewport({ scale: scale });

        const canvas = document.createElement('canvas');
        canvas.className = 'pdf-page-canvas';
        canvas.id = 'page-canvas-' + pageNum;
        canvas.height = viewport.height;
        canvas.width = viewport.width;

        const wrapper = document.createElement('div');
        wrapper.style.position = 'relative';
        wrapper.appendChild(canvas);
        container.appendChild(wrapper);

        await page.render({ canvasContext: canvas.getContext('2d'), viewport: viewport }).promise;
    }
}

function changePage(delta) {
    const target = currentPage + delta;
    if (target < 1 || target > totalPages) return;
    currentPage = target;
    const canvas = document.getElementById('page-canvas-' + currentPage);
    if (canvas) canvas.scrollIntoView({ behavior: 'smooth', block: 'start' });
    document.getElementById('page-info').textContent = 'Page ' + currentPage + ' of ' + totalPages;
    document.getElementById('btn-prev').disabled = currentPage <= 1;
    document.getElementById('btn-next').disabled = currentPage >= totalPages;
}

function changeZoom(delta, fit = false) {
    if (fit) {
        const container = document.getElementById('panel-viewer');
        scale = (container.clientWidth - 60) / 800;
    } else {
        scale = Math.max(0.5, Math.min(3.0, scale + delta));
    }
    document.getElementById('zoom-level').textContent = Math.round(scale * 100) + '%';
    renderAllPages();
}

// Track current page while scrolling
document.getElementById('panel-viewer').addEventListener('scroll', function() {
    for (let i = 1; i <= totalPages; i++) {
        const c = document.getElementById('page-canvas-' + i);
        if (!c) continue;
        const rect = c.getBoundingClientRect();
        if (rect.top >= 0 && rect.top < window.innerHeight / 2) {
            currentPage = i;
            document.getElementById('page-info').textContent = 'Page ' + i + ' of ' + totalPages;
            document.getElementById('btn-prev').disabled = i <= 1;
            document.getElementById('btn-next').disabled = i >= totalPages;
            break;
        }
    }
});

// Load on start
loadPDF();
</script>
</body>
</html>
