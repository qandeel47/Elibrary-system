<?php
session_start();
if (!empty($_SESSION['student_id'])) { header('Location: dashboard.php'); exit; }
require_once __DIR__ . '/includes/config.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = trim($_POST['student_id'] ?? '');
    $password   = $_POST['password'] ?? '';

    $stmt = $dbh->prepare("SELECT * FROM tbl_students WHERE student_id = :sid AND status = 1 LIMIT 1");
    $stmt->execute([':sid' => $student_id]);
    $student = $stmt->fetch();

    if ($student && password_verify($password, $student->password)) {
        $_SESSION['student_id']   = $student->id;
        $_SESSION['student_name'] = $student->full_name;
        $_SESSION['student_roll'] = $student->student_id;
        header('Location: dashboard.php'); exit;
    } else {
        $error = 'Invalid Student ID or password. Please contact the library admin.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Login — Superior E-Library</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="login-wrapper">
    <div class="login-left">
        <div style="display:flex;align-items:center;gap:14px;margin-bottom:36px;">
            <img src="../assets/img/logo.png" style="height:52px;background:white;border-radius:10px;padding:5px;" alt="Logo">
            <div>
                <div style="font-family:'Playfair Display',serif;font-size:20px;color:white;font-weight:700;">Superior University</div>
                <div style="font-size:12px;color:rgba(255,255,255,0.65);">E-Library Management System</div>
            </div>
        </div>
        <h1>Student<br>Portal</h1>
        <p>Access your library account to browse books, read e-books online, download PDFs, and track your borrowed books.</p>
        <div style="margin-top:40px;display:flex;gap:20px;flex-wrap:wrap;">
            <div style="color:rgba(255,255,255,0.8);font-size:13px;">📖 Read E-Books</div>
            <div style="color:rgba(255,255,255,0.8);font-size:13px;">📥 Download PDFs</div>
            <div style="color:rgba(255,255,255,0.8);font-size:13px;">📋 Track Borrows</div>
            <div style="color:rgba(255,255,255,0.8);font-size:13px;">💰 View Fines</div>
        </div>
    </div>
    <div class="login-right">
        <h2>Student Login</h2>
        <p class="sub">Use your Student ID and password</p>

        <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label class="form-label">Student ID / Roll Number</label>
                <input type="text" name="student_id" class="form-control" placeholder="e.g. SUP-2024-001" required value="<?= htmlspecialchars($_POST['student_id'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Your password" required>
            </div>
            <button type="submit" class="btn btn-primary btn-full">Sign In</button>
        </form>

        <div style="margin-top:24px;padding:14px;background:#f5f0fa;border-radius:8px;font-size:13px;color:#4b2c5e;">
            ℹ️ Your <strong>Student ID</strong> and <strong>password</strong> are set by the library admin. Visit the library desk if you need access.
        </div>
        <div style="margin-top:16px;text-align:center;font-size:13px;color:#7a6b8a;">
            <a href="../index.php">← Back to Home</a>
        </div>
    </div>
</div>
</body>
</html>
