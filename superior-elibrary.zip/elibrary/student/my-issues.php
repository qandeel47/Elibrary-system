<?php
define('IN_STUDENT', true);
session_start();
if (empty($_SESSION['student_id'])) { header('Location: login.php'); exit; }
require_once __DIR__ . '/includes/config.php';
$page_title = 'My Issued Books';
$sid = (int)$_SESSION['student_id'];

$filter = $_GET['filter'] ?? 'active';
$sql = "SELECT i.*, b.book_name, b.book_image, a.author_name,
               DATEDIFF(CURDATE(), i.due_date) as days_late
        FROM tbl_issues i
        JOIN tbl_books b ON b.id=i.book_id
        LEFT JOIN tbl_authors a ON a.id=b.author_id
        WHERE i.student_id=:id";
if ($filter === 'active')   $sql .= " AND i.status='issued'";
if ($filter === 'returned') $sql .= " AND i.status='returned'";
if ($filter === 'overdue')  $sql .= " AND i.status='issued' AND i.due_date < CURDATE()";
$sql .= " ORDER BY i.id DESC";
$stmt = $dbh->prepare($sql);
$stmt->execute([':id'=>$sid]);
$issues = $stmt->fetchAll();

$finePerDay = (float)getSetting('fine_per_day');
$loanDays   = getSetting('loan_days');
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="page-title"><h2>My Borrowed Physical Books</h2><p>Track physical books you have borrowed from the library</p></div>

<div style="display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap;">
    <?php foreach (['active'=>'Currently Issued','overdue'=>'Overdue','returned'=>'Returned','all'=>'All History'] as $k=>$lbl): ?>
    <a href="?filter=<?= $k ?>" class="btn <?= $filter===$k?'btn-primary':'btn-secondary' ?>"><?= $lbl ?></a>
    <?php endforeach; ?>
</div>

<div class="el-card">
    <div class="el-card-header">📋 <?= ['active'=>'Currently Issued','overdue'=>'Overdue Books','returned'=>'Returned Books','all'=>'All Issues'][$filter] ?? 'Issues' ?> (<?= count($issues) ?>)</div>
    <div class="p-0">
        <?php if ($issues): ?>
        <table class="el-table">
            <thead>
                <tr><th>Book</th><th>Issue Date</th><th>Due Date</th><th>Return Date</th><th>Fine</th><th>Status</th></tr>
            </thead>
            <tbody>
                <?php foreach ($issues as $i): ?>
                <?php
                $overdue = ($i->status === 'issued' && $i->days_late > 0);
                $fine = $i->fine_amount > 0 ? $i->fine_amount : ($overdue ? $i->days_late * $finePerDay : 0);
                ?>
                <tr <?= $overdue?'class="row-overdue"':'' ?>>
                    <td>
                        <div style="display:flex;align-items:center;gap:10px;">
                            <?php if ($i->book_image && file_exists(dirname(__DIR__) . "/admin/bookimg/{$i->book_image}")): ?>
                            <img src="../admin/bookimg/<?= htmlspecialchars($i->book_image) ?>" style="width:36px;height:48px;object-fit:cover;border-radius:4px;">
                            <?php else: ?>
                            <div style="width:36px;height:48px;background:#e8d5f5;border-radius:4px;display:flex;align-items:center;justify-content:center;">📗</div>
                            <?php endif; ?>
                            <div>
                                <div style="font-weight:600;font-size:13px;"><?= htmlspecialchars($i->book_name) ?></div>
                                <div style="font-size:11px;color:#7a6b8a;"><?= htmlspecialchars($i->author_name ?? '') ?></div>
                            </div>
                        </div>
                    </td>
                    <td><?= date('d M Y', strtotime($i->issue_date)) ?></td>
                    <td class="<?= $overdue?'text-danger fw-bold':'' ?>"><?= date('d M Y', strtotime($i->due_date)) ?></td>
                    <td><?= $i->return_date ? date('d M Y', strtotime($i->return_date)) : '<span class="text-muted">—</span>' ?></td>
                    <td>
                        <?php if ($fine > 0): ?>
                        <span class="text-danger fw-bold">₨<?= number_format($fine,0) ?></span>
                        <?= $i->fine_paid ? '<br><span class="badge badge-success" style="font-size:10px;">Paid</span>' : '' ?>
                        <?php else: ?>
                        <span class="text-muted">—</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($i->status==='returned'): ?>
                        <span class="badge badge-success">Returned</span>
                        <?php elseif ($overdue): ?>
                        <span class="badge badge-danger">⚠️ Overdue</span>
                        <?php else: ?>
                        <span class="badge badge-info">Issued</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="no-data">
            <?php if ($filter==='active'): ?>
            You currently have no physical books borrowed. <a href="browse-books.php">Browse the library →</a>
            <?php else: ?>
            No records found.
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<div class="alert alert-info" style="font-size:13px;">
    📦 This page shows <strong>physical book borrowing only</strong>. E-books can always be read or downloaded freely from Browse Books.
    📅 Loan period: <strong><?= $loanDays ?> days</strong> &nbsp;|&nbsp; Fine: <strong>₨<?= $finePerDay ?>/day</strong> after due date. To return, bring the book to the library desk.
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
