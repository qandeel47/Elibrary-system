<?php
define('IN_STUDENT', true);
session_start();
if (empty($_SESSION['student_id'])) { header('Location: login.php'); exit; }
require_once __DIR__ . '/includes/config.php';
$page_title = 'My Fines';
$sid = (int)$_SESSION['student_id'];

$finePerDay = (float)getSetting('fine_per_day');

// Update running fines for active overdue
$dbh->prepare("UPDATE tbl_issues SET fine_amount = DATEDIFF(CURDATE(), due_date) * :fpd
               WHERE student_id=:sid AND status='issued' AND due_date < CURDATE()")
    ->execute([':fpd'=>$finePerDay, ':sid'=>$sid]);

$fines = $dbh->prepare("
    SELECT i.*, b.book_name
    FROM tbl_issues i
    JOIN tbl_books b ON b.id=i.book_id
    WHERE i.student_id=:sid AND i.fine_amount > 0
    ORDER BY i.fine_paid ASC, i.fine_amount DESC
");
$fines->execute([':sid'=>$sid]);
$fines = $fines->fetchAll();

$totalPending = $dbh->prepare("SELECT COALESCE(SUM(fine_amount),0) FROM tbl_issues WHERE student_id=:sid AND fine_paid=0 AND fine_amount>0");
$totalPending->execute([':sid'=>$sid]);
$totalPending = $totalPending->fetchColumn();

$totalPaid = $dbh->prepare("SELECT COALESCE(SUM(fine_amount),0) FROM tbl_issues WHERE student_id=:sid AND fine_paid=1");
$totalPaid->execute([':sid'=>$sid]);
$totalPaid = $totalPaid->fetchColumn();
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="page-title"><h2>My Fines</h2><p>View your overdue fines and payment status</p></div>

<div class="stats-grid" style="grid-template-columns:repeat(2,1fr);max-width:480px;">
    <div class="stat-card red">
        <div class="stat-icon">💸</div>
        <div><div class="stat-num">₨<?= number_format($totalPending,0) ?></div><div class="stat-lbl">Pending Fines</div></div>
    </div>
    <div class="stat-card green">
        <div class="stat-icon">✅</div>
        <div><div class="stat-num">₨<?= number_format($totalPaid,0) ?></div><div class="stat-lbl">Paid Fines</div></div>
    </div>
</div>

<?php if ($totalPending > 0): ?>
<div class="alert alert-danger">
    ⚠️ You have <strong>₨<?= number_format($totalPending,0) ?></strong> in unpaid fines. Please visit the library desk to clear your dues.
    You may not be able to borrow additional books until fines are cleared.
</div>
<?php else: ?>
<div class="alert alert-success">✅ You have no pending fines. Keep returning books on time!</div>
<?php endif; ?>

<div class="el-card">
    <div class="el-card-header">💰 Fine History (<?= count($fines) ?>)</div>
    <div class="p-0">
        <?php if ($fines): ?>
        <table class="el-table">
            <thead>
                <tr><th>Book</th><th>Due Date</th><th>Return Date</th><th>Days Late</th><th>Fine</th><th>Status</th></tr>
            </thead>
            <tbody>
                <?php foreach ($fines as $f): ?>
                <?php
                if ($f->return_date) {
                    $daysLate = max(0, (int)floor((strtotime($f->return_date) - strtotime($f->due_date)) / 86400));
                } else {
                    $daysLate = max(0, (int)floor((time() - strtotime($f->due_date)) / 86400));
                }
                ?>
                <tr <?= !$f->fine_paid ? 'class="row-overdue"' : '' ?>>
                    <td><?= htmlspecialchars($f->book_name) ?></td>
                    <td><?= date('d M Y', strtotime($f->due_date)) ?></td>
                    <td><?= $f->return_date ? date('d M Y', strtotime($f->return_date)) : '<span class="badge badge-danger">Not returned yet</span>' ?></td>
                    <td><span class="badge badge-danger"><?= $daysLate ?> days</span></td>
                    <td class="fw-bold <?= $f->fine_paid ? '' : 'text-danger' ?>">₨<?= number_format($f->fine_amount,0) ?></td>
                    <td>
                        <?= $f->fine_paid
                            ? '<span class="badge badge-success">✅ Paid</span>'
                            : '<span class="badge badge-danger">⏳ Unpaid</span>' ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="no-data">🎉 You have no fines on record.</div>
        <?php endif; ?>
    </div>
</div>

<div class="alert alert-info" style="font-size:13px;">
    ℹ️ Fine rate: <strong>₨<?= $finePerDay ?> per day</strong> after the due date.
    To pay your fine, visit the library desk with your student ID.
    Fines are marked as paid by the admin after collection.
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
