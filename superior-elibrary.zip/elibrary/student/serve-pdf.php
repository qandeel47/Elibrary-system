<?php
// Serves PDF files securely - only for logged-in students
session_start();
if (empty($_SESSION['student_id'])) {
    http_response_code(403);
    exit('Access denied.');
}
require_once __DIR__ . '/includes/config.php';

$book_id = (int)($_GET['id'] ?? 0);
if (!$book_id) { http_response_code(404); exit('Not found.'); }

$stmt = $dbh->prepare("SELECT ebook_file, book_name FROM tbl_books WHERE id=:id AND status=1");
$stmt->execute([':id' => $book_id]);
$book = $stmt->fetch();

if (!$book || !$book->ebook_file) {
    http_response_code(404); exit('E-book not found.');
}

$filepath = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'ebooks' . DIRECTORY_SEPARATOR . $book->ebook_file;

if (!file_exists($filepath)) {
    http_response_code(404); exit('File not found on server. Please contact the admin.');
}

$inline = !isset($_GET['download']);

header('Content-Type: application/pdf');
header('Content-Length: ' . filesize($filepath));
if ($inline) {
    header('Content-Disposition: inline; filename="' . basename($filepath) . '"');
} else {
    $safeName = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $book->book_name);
    header('Content-Disposition: attachment; filename="' . $safeName . '.pdf"');
    // Log download
    $log = $dbh->prepare("INSERT INTO tbl_ebook_log (book_id, student_id, action) VALUES (:bid, :sid, 'download')");
    $log->execute([':bid'=>$book_id, ':sid'=>$_SESSION['student_id']]);
}
header('Cache-Control: private, max-age=0, must-revalidate');
readfile($filepath);
exit;
