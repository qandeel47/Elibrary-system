<?php
session_start();
if (!empty($_SESSION['admin_id'])) { header('Location: dashboard.php'); exit; }
include __DIR__ . '/includes/config.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $dbh->prepare("SELECT * FROM tbl_admin WHERE email = :email LIMIT 1");
    $stmt->execute([':email' => $email]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin->password)) {
        $_SESSION['admin_id']   = $admin->id;
        $_SESSION['admin_name'] = $admin->full_name;
        header('Location: dashboard.php'); exit;
    } else {
        $error = 'Invalid email or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login — Superior E-Library</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="login-wrapper">

    <div class="login-left">
        <div style="display:flex;align-items:center;gap:14px;margin-bottom:36px;">
            <img src="../assets/img/logo.png" style="height:52px;background:white;border-radius:10px;padding:5px;" alt="Logo">
            <div>
                <div style="font-family:'Playfair Display',serif;font-size:20px;color:white;font-weight:700;">Superior University</div>
                <div style="font-size:12px;color:rgba(255,255,255,0.65);">E-Library Management System</div>
            </div>
        </div>
        <h1>Admin<br>Control Panel</h1>
        <p>Manage your entire library from one place — books, students, issues, returns, and fines.</p>
        <div style="margin-top:40px;display:flex;gap:24px;flex-wrap:wrap;">
            <div style="color:rgba(255,255,255,0.8);font-size:13px;">📚 Books Management</div>
            <div style="color:rgba(255,255,255,0.8);font-size:13px;">👥 Student Management</div>
            <div style="color:rgba(255,255,255,0.8);font-size:13px;">💰 Fine Tracking</div>
            <div style="color:rgba(255,255,255,0.8);font-size:13px;">📊 Activity Logs</div>
        </div>
    </div>

    <div class="login-right">
        <h2>Welcome Back</h2>
        <p class="sub">Sign in to your admin account</p>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label class="form-label">Email Address</label>
                <input type="email" name="email" class="form-control" placeholder="admin@elibrary.edu" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
            </div>
            <button type="submit" class="btn btn-primary btn-full" style="margin-top:8px;">Sign In</button>
        </form>

        <div style="margin-top:20px;text-align:center;font-size:13px;color:#7a6b8a;">
            Don't have an account? <a href="register.php">Register here</a>
        </div>
        <div style="margin-top:12px;text-align:center;font-size:13px;color:#7a6b8a;">
            <a href="../index.php">← Back to Home</a>
        </div>
    </div>

</div>
</body>
</html>
