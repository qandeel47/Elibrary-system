<?php
define('IN_ADMIN', true);
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
include __DIR__ . '/includes/config.php';
$page_title = 'Student Profile';

$id = (int)($_GET['id'] ?? 0);
$stmt = $dbh->prepare("SELECT * FROM tbl_students WHERE id=:id");
$stmt->execute([':id'=>$id]);
$student = $stmt->fetch();
if (!$student) { header('Location: manage-students.php'); exit; }

$issues = $dbh->prepare("SELECT i.*, b.book_name FROM tbl_issues i JOIN tbl_books b ON b.id=i.book_id WHERE i.student_id=:id ORDER BY i.id DESC");
$issues->execute([':id'=>$id]);
$issues = $issues->fetchAll();

$ebookLog = $dbh->prepare("SELECT l.*, b.book_name FROM tbl_ebook_log l JOIN tbl_books b ON b.id=l.book_id WHERE l.student_id=:id ORDER BY l.id DESC LIMIT 20");
$ebookLog->execute([':id'=>$id]);
$ebookLog = $ebookLog->fetchAll();

$totalFine = $dbh->prepare("SELECT COALESCE(SUM(fine_amount),0) FROM tbl_issues WHERE student_id=:id AND fine_paid=0");
$totalFine->execute([':id'=>$id]);
$totalFine = $totalFine->fetchColumn();
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="page-title d-flex justify-between align-center">
    <div>
        <h2><?= htmlspecialchars($student->full_name) ?></h2>
        <p>Student ID: <?= htmlspecialchars($student->student_id) ?></p>
    </div>
    <a href="manage-students.php" class="btn btn-secondary">← Back</a>
</div>

<div class="row">
    <div class="col-6" style="max-width:340px;">
        <div class="el-card">
            <div class="el-card-header">👤 Profile</div>
            <div class="el-card-body">
                <div style="text-align:center;margin-bottom:20px;">
                    <div style="width:80px;height:80px;border-radius:50%;background:#e8d5f5;display:inline-flex;align-items:center;justify-content:center;font-size:36px;margin-bottom:10px;">👤</div>
                    <div style="font-size:18px;font-weight:700;color:#4b2c5e;"><?= htmlspecialchars($student->full_name) ?></div>
                    <div style="font-size:13px;color:#7a6b8a;"><?= htmlspecialchars($student->student_id) ?></div>
                </div>
                <table style="width:100%;font-size:13px;">
                    <tr><td style="color:#7a6b8a;padding:5px 0;">Email</td><td><?= htmlspecialchars($student->email) ?></td></tr>
                    <tr><td style="color:#7a6b8a;padding:5px 0;">Phone</td><td><?= htmlspecialchars($student->phone ?: '—') ?></td></tr>
                    <tr><td style="color:#7a6b8a;padding:5px 0;">Department</td><td><?= htmlspecialchars($student->department ?: '—') ?></td></tr>
                    <tr><td style="color:#7a6b8a;padding:5px 0;">Registered</td><td><?= date('d M Y', strtotime($student->created_at)) ?></td></tr>
                    <tr><td style="color:#7a6b8a;padding:5px 0;">Status</td><td><?= $student->status ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-danger">Inactive</span>' ?></td></tr>
                    <tr><td style="color:#7a6b8a;padding:5px 0;">Pending Fine</td><td class="<?= $totalFine>0?'text-danger fw-bold':'' ?>">₨<?= number_format($totalFine,0) ?></td></tr>
                </table>
            </div>
        </div>
    </div>

    <div class="col-6" style="flex:1;">
        <div class="el-card" style="margin-bottom:20px;">
            <div class="el-card-header">📚 Issue History (<?= count($issues) ?>)</div>
            <div class="p-0">
                <?php if ($issues): ?>
                <table class="el-table">
                    <thead><tr><th>Book</th><th>Issue</th><th>Due</th><th>Return</th><th>Fine</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php foreach ($issues as $i): ?>
                        <tr>
                            <td><?= htmlspecialchars($i->book_name) ?></td>
                            <td><?= date('d M Y', strtotime($i->issue_date)) ?></td>
                            <td><?= date('d M Y', strtotime($i->due_date)) ?></td>
                            <td><?= $i->return_date ? date('d M Y', strtotime($i->return_date)) : '—' ?></td>
                            <td><?= $i->fine_amount > 0 ? '<span class="text-danger">₨'.$i->fine_amount.'</span>' : '—' ?></td>
                            <td>
                                <?php if ($i->status==='returned'): ?>
                                    <span class="badge badge-success">Returned</span>
                                <?php elseif ($i->status==='issued' && $i->due_date < date('Y-m-d')): ?>
                                    <span class="badge badge-danger">Overdue</span>
                                <?php else: ?>
                                    <span class="badge badge-info">Issued</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?><div class="no-data">No issue history.</div><?php endif; ?>
            </div>
        </div>

        <div class="el-card">
            <div class="el-card-header">📖 E-Book Activity</div>
            <div class="p-0">
                <?php if ($ebookLog): ?>
                <table class="el-table">
                    <thead><tr><th>Book</th><th>Action</th><th>Date</th></tr></thead>
                    <tbody>
                        <?php foreach ($ebookLog as $l): ?>
                        <tr>
                            <td><?= htmlspecialchars($l->book_name) ?></td>
                            <td><span class="badge <?= $l->action==='download'?'badge-info':'badge-primary' ?>"><?= ucfirst($l->action) ?></span></td>
                            <td><?= date('d M Y H:i', strtotime($l->created_at)) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?><div class="no-data">No e-book activity.</div><?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
