<?php
define('IN_ADMIN', true);
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
include __DIR__ . '/includes/config.php';
$page_title = 'Settings';

$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fields = ['fine_per_day', 'loan_days', 'library_name'];
    foreach ($fields as $f) {
        if (isset($_POST[$f])) {
            $val = trim($_POST[$f]);
            $dbh->prepare("UPDATE tbl_settings SET setting_value=:v WHERE setting_key=:k")->execute([':v'=>$val, ':k'=>$f]);
        }
    }

    // Change admin password
    if (!empty($_POST['new_password'])) {
        if ($_POST['new_password'] === $_POST['confirm_password']) {
            $hashed = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
            $dbh->prepare("UPDATE tbl_admin SET password=:p WHERE id=:id")->execute([':p'=>$hashed, ':id'=>$_SESSION['admin_id']]);
            $success = 'Settings and password updated.';
        } else {
            $success = 'Settings saved. Passwords did not match — password not changed.';
        }
    } else {
        $success = 'Settings saved successfully.';
    }
}

$finePerDay  = getSetting('fine_per_day');
$loanDays    = getSetting('loan_days');
$libraryName = getSetting('library_name');
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="page-title"><h2>System Settings</h2><p>Configure library rules and preferences</p></div>

<?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

<div class="row">
    <div class="col-6">
        <div class="el-card">
            <div class="el-card-header">⚙️ Library Settings</div>
            <div class="el-card-body">
                <form method="POST">
                    <div class="form-group">
                        <label class="form-label">Library Name</label>
                        <input type="text" name="library_name" class="form-control" value="<?= htmlspecialchars($libraryName) ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Loan Period (Days)</label>
                        <input type="number" name="loan_days" class="form-control" value="<?= htmlspecialchars($loanDays) ?>" min="1" max="365">
                        <small class="text-muted">How many days students can borrow a book</small>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Fine Per Day (₨)</label>
                        <input type="number" name="fine_per_day" class="form-control" value="<?= htmlspecialchars($finePerDay) ?>" min="0" step="0.50">
                        <small class="text-muted">Charged per day after due date</small>
                    </div>

                    <hr style="border-color:#e2d4f0;margin:20px 0;">
                    <h4 style="font-size:16px;margin-bottom:16px;">Change Password</h4>

                    <div class="form-group">
                        <label class="form-label">New Password</label>
                        <input type="password" name="new_password" class="form-control" placeholder="Leave blank to keep current">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Confirm New Password</label>
                        <input type="password" name="confirm_password" class="form-control" placeholder="Repeat new password">
                    </div>
                    <button type="submit" class="btn btn-primary">💾 Save Settings</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-6">
        <div class="el-card">
            <div class="el-card-header">📋 Current Configuration</div>
            <div class="el-card-body">
                <table style="width:100%;font-size:14px;">
                    <tr style="padding:10px 0;"><td style="color:#7a6b8a;padding:10px 0;">Library Name</td><td><strong><?= htmlspecialchars($libraryName) ?></strong></td></tr>
                    <tr><td style="color:#7a6b8a;padding:10px 0;">Loan Period</td><td><strong><?= $loanDays ?> days</strong></td></tr>
                    <tr><td style="color:#7a6b8a;padding:10px 0;">Fine Rate</td><td><strong>₨<?= $finePerDay ?> per day</strong></td></tr>
                </table>
                <div style="margin-top:24px;padding:16px;background:#f5f0fa;border-radius:8px;">
                    <div style="font-size:13px;color:#4b2c5e;font-weight:600;margin-bottom:8px;">Example Fine Calculation</div>
                    <div style="font-size:13px;color:#7a6b8a;">
                        If a student returns a book <strong>5 days late</strong>:<br>
                        Fine = 5 × ₨<?= $finePerDay ?> = <strong>₨<?= 5*$finePerDay ?></strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
