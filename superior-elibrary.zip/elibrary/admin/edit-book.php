<?php
define('IN_ADMIN', true);
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
include __DIR__ . '/includes/config.php';
$page_title = 'Edit Book';

$id = (int)($_GET['id'] ?? 0);
$stmt = $dbh->prepare("SELECT * FROM tbl_books WHERE id=:id");
$stmt->execute([':id'=>$id]);
$book = $stmt->fetch();
if (!$book) { header('Location: manage-books.php'); exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $book_name   = trim($_POST['book_name'] ?? '');
    $category_id = (int)($_POST['category_id'] ?? 0);
    $author_id   = (int)($_POST['author_id'] ?? 0);
    $isbn        = trim($_POST['isbn'] ?? '');
    $total_qty   = (int)($_POST['total_qty'] ?? 1);
    $available_qty = (int)($_POST['available_qty'] ?? 0);
    $description = trim($_POST['description'] ?? '');
    $book_image  = $book->book_image;
    $ebook_file  = $book->ebook_file;

    if (!empty($_FILES['book_image']['name'])) {
        $ext = strtolower(pathinfo($_FILES['book_image']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg','jpeg','png','gif','webp'])) {
            if ($book_image && file_exists(__DIR__ . "/bookimg/$book_image")) unlink(__DIR__ . "/bookimg/$book_image");
            $book_image = md5(uniqid()) . '.' . $ext;
            move_uploaded_file($_FILES['book_image']['tmp_name'], __DIR__ . "/bookimg/$book_image");
        }
    }

    if (!empty($_FILES['ebook_file']['name'])) {
        $ext2 = strtolower(pathinfo($_FILES['ebook_file']['name'], PATHINFO_EXTENSION));
        if ($ext2 === 'pdf') {
            if (!is_dir(dirname(__DIR__) . '/assets/ebooks')) mkdir(dirname(__DIR__) . '/assets/ebooks', 0755, true);
            if ($ebook_file && file_exists(dirname(__DIR__) . "/assets/ebooks/$ebook_file")) unlink(dirname(__DIR__) . "/assets/ebooks/$ebook_file");
            $ebook_file = md5(uniqid()) . '.pdf';
            move_uploaded_file($_FILES['ebook_file']['tmp_name'], dirname(__DIR__) . "/assets/ebooks/$ebook_file");
        }
    }

    try {
        $stmt = $dbh->prepare("UPDATE tbl_books SET book_name=:bn, category_id=:cat, author_id=:auth, isbn=:isbn,
                                book_image=:img, total_qty=:qty, available_qty=:aq, ebook_file=:ebook, description=:desc WHERE id=:id");
        $stmt->execute([':bn'=>$book_name, ':cat'=>$category_id, ':auth'=>$author_id, ':isbn'=>$isbn,
                        ':img'=>$book_image, ':qty'=>$total_qty, ':aq'=>$available_qty, ':ebook'=>$ebook_file, ':desc'=>$description, ':id'=>$id]);
        header('Location: manage-books.php?msg=updated'); exit;
    } catch (PDOException $e) {
        $error = 'ISBN already exists or error: ' . $e->getMessage();
    }
}

$categories = $dbh->query("SELECT * FROM tbl_categories WHERE status=1 ORDER BY category_name")->fetchAll();
$authors    = $dbh->query("SELECT * FROM tbl_authors ORDER BY author_name")->fetchAll();
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="page-title">
    <h2>Edit Book</h2>
    <p><?= htmlspecialchars($book->book_name) ?></p>
</div>

<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="el-card">
    <div class="el-card-header">✏️ Edit Book Details</div>
    <div class="el-card-body">
        <form method="POST" enctype="multipart/form-data">
            <div class="row">
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">Book Name *</label>
                        <input type="text" name="book_name" class="form-control" required value="<?= htmlspecialchars($book->book_name) ?>">
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">ISBN *</label>
                        <input type="text" name="isbn" class="form-control" required value="<?= htmlspecialchars($book->isbn) ?>">
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">Category *</label>
                        <select name="category_id" class="form-control" required>
                            <?php foreach ($categories as $c): ?>
                            <option value="<?= $c->id ?>" <?= $book->category_id==$c->id?'selected':'' ?>><?= htmlspecialchars($c->category_name) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">Author *</label>
                        <select name="author_id" class="form-control" required>
                            <?php foreach ($authors as $a): ?>
                            <option value="<?= $a->id ?>" <?= $book->author_id==$a->id?'selected':'' ?>><?= htmlspecialchars($a->author_name) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">Total Quantity</label>
                        <input type="number" name="total_qty" class="form-control" min="1" value="<?= $book->total_qty ?>">
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">Available Quantity</label>
                        <input type="number" name="available_qty" class="form-control" min="0" max="<?= $book->total_qty ?>" value="<?= $book->available_qty ?>">
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">New Cover Image</label>
                        <?php if ($book->book_image): ?>
                        <div style="margin-bottom:8px;">
                            <img src="bookimg/<?= htmlspecialchars($book->book_image) ?>" style="height:60px;border-radius:4px;">
                        </div>
                        <?php endif; ?>
                        <input type="file" name="book_image" class="form-control" accept="image/*">
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">New E-Book PDF</label>
                        <?php if ($book->ebook_file): ?>
                        <div style="margin-bottom:8px;"><span class="badge badge-success">PDF Uploaded ✓</span></div>
                        <?php endif; ?>
                        <input type="file" name="ebook_file" class="form-control" accept=".pdf">
                    </div>
                </div>
                <div class="col-12">
                    <div class="form-group">
                        <label class="form-label">Description</label>
                        <textarea name="description" class="form-control" rows="4"><?= htmlspecialchars($book->description) ?></textarea>
                    </div>
                </div>
            </div>
            <div style="display:flex;gap:10px;margin-top:8px;">
                <button type="submit" class="btn btn-primary">💾 Save Changes</button>
                <a href="manage-books.php" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
