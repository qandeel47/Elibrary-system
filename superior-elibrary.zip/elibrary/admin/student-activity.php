<?php
define('IN_ADMIN', true);
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
include __DIR__ . '/includes/config.php';
$page_title = 'Student Activity';

$logs = $dbh->query("
    SELECT l.*, b.book_name, s.full_name as student_name, s.student_id as sid
    FROM tbl_ebook_log l
    JOIN tbl_books b ON b.id=l.book_id
    JOIN tbl_students s ON s.id=l.student_id
    ORDER BY l.id DESC LIMIT 200
")->fetchAll();
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="page-title"><h2>Student Activity Log</h2><p>E-book reads and downloads by students</p></div>

<div class="el-card">
    <div class="el-card-header">📈 E-Book Activity (last 200)</div>
    <div class="p-0">
        <?php if ($logs): ?>
        <table class="el-table">
            <thead><tr><th>#</th><th>Student</th><th>Book</th><th>Action</th><th>Date & Time</th></tr></thead>
            <tbody>
                <?php $n=1; foreach ($logs as $l): ?>
                <tr>
                    <td><?= $n++ ?></td>
                    <td><?= htmlspecialchars($l->student_name) ?><br><small class="text-muted"><?= htmlspecialchars($l->sid) ?></small></td>
                    <td><?= htmlspecialchars($l->book_name) ?></td>
                    <td>
                        <?= $l->action==='download'
                            ? '<span class="badge badge-info">📥 Download</span>'
                            : '<span class="badge badge-primary">📖 Read</span>' ?>
                    </td>
                    <td><?= date('d M Y, H:i', strtotime($l->created_at)) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="no-data">No activity recorded yet.</div>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
