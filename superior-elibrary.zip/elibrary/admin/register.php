<?php
// NOTE: No session redirect here - admin can create additional admin accounts
// even while logged in, or can register before first login
session_start();
include __DIR__ . '/includes/config.php';

$error = $success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $admin_id  = trim($_POST['admin_id'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $password  = $_POST['password'] ?? '';
    $confirm   = $_POST['confirm_password'] ?? '';

    if (empty($admin_id) || empty($full_name) || empty($email) || empty($password)) {
        $error = 'All fields are required.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } else {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        try {
            $stmt = $dbh->prepare("INSERT INTO tbl_admin (admin_id, full_name, email, password) VALUES (:aid, :name, :email, :pass)");
            $stmt->execute([':aid'=>$admin_id, ':name'=>$full_name, ':email'=>$email, ':pass'=>$hashed]);
            $success = 'Admin account created! <a href="login.php">Click here to login →</a>';
        } catch (PDOException $e) {
            $error = 'Admin ID or Email already exists. Please choose a different one.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Register — Superior E-Library</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="login-wrapper">
    <div class="login-left">
        <div style="display:flex;align-items:center;gap:14px;margin-bottom:36px;">
            <img src="../assets/img/logo.png" style="height:52px;background:white;border-radius:10px;padding:5px;" alt="Logo">
            <div>
                <div style="font-family:'Playfair Display',serif;font-size:20px;color:white;font-weight:700;">Superior University</div>
                <div style="font-size:12px;color:rgba(255,255,255,0.65);">E-Library Management System</div>
            </div>
        </div>
        <h1>Create Admin<br>Account</h1>
        <p>Register a new administrator to manage the Superior University E-Library system.</p>
        <div style="margin-top:32px;padding:16px;background:rgba(255,255,255,0.1);border-radius:10px;">
            <div style="font-size:13px;color:rgba(255,255,255,0.85);line-height:1.8;">
                ✅ Manage all books<br>
                ✅ Add &amp; manage students<br>
                ✅ Issue &amp; return books<br>
                ✅ Track fines &amp; activity
            </div>
        </div>
    </div>

    <div class="login-right">
        <h2>Admin Registration</h2>
        <p class="sub">Create a new admin account</p>

        <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <?php if ($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>

        <?php if (!$success): ?>
        <form method="POST">
            <div class="form-group">
                <label class="form-label">Admin ID <span style="color:red">*</span></label>
                <input type="text" name="admin_id" class="form-control" placeholder="e.g. ADM002" required value="<?= htmlspecialchars($_POST['admin_id'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Full Name <span style="color:red">*</span></label>
                <input type="text" name="full_name" class="form-control" placeholder="Your full name" required value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Email Address <span style="color:red">*</span></label>
                <input type="email" name="email" class="form-control" placeholder="admin@elibrary.edu" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Password <span style="color:red">*</span></label>
                <input type="password" name="password" class="form-control" placeholder="Minimum 6 characters" required>
            </div>
            <div class="form-group">
                <label class="form-label">Confirm Password <span style="color:red">*</span></label>
                <input type="password" name="confirm_password" class="form-control" placeholder="Repeat password" required>
            </div>
            <button type="submit" class="btn btn-primary btn-full">Create Admin Account</button>
        </form>
        <?php endif; ?>

        <div style="margin-top:20px;text-align:center;font-size:13px;color:#7a6b8a;">
            Already have an account? <a href="login.php">Login here</a>
        </div>
        <div style="margin-top:10px;text-align:center;font-size:13px;color:#7a6b8a;">
            <a href="../index.php">← Back to Home</a>
        </div>
    </div>
</div>
</body>
</html>
