<?php
define('IN_ADMIN', true);
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
include __DIR__ . '/includes/config.php';
$page_title = 'Issued Books';

$filter = $_GET['filter'] ?? 'all';
$search = trim($_GET['s'] ?? '');

$sql = "SELECT i.*, b.book_name, s.full_name as student_name, s.student_id as sid,
               DATEDIFF(CURDATE(), i.due_date) as days_overdue
        FROM tbl_issues i
        JOIN tbl_books b ON b.id=i.book_id
        JOIN tbl_students s ON s.id=i.student_id
        WHERE 1=1";
$params = [];

if ($filter === 'active')   $sql .= " AND i.status='issued'";
if ($filter === 'returned') $sql .= " AND i.status='returned'";
if ($filter === 'overdue')  $sql .= " AND i.status='issued' AND i.due_date < CURDATE()";

if ($search) {
    $sql .= " AND (s.full_name LIKE :s OR s.student_id LIKE :s2 OR b.book_name LIKE :s3)";
    $params = [':s'=>"%$search%",':s2'=>"%$search%",':s3'=>"%$search%"];
}
$sql .= " ORDER BY i.id DESC";
$stmt = $dbh->prepare($sql); $stmt->execute($params);
$issues = $stmt->fetchAll();

$finePerDay = (float)getSetting('fine_per_day');
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="page-title d-flex justify-between align-center">
    <div><h2>Physical Book Issue Log</h2><p>Complete history of all physical book issues and returns — e-books are separate</p></div>
</div>

<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px;">
    <?php foreach (['all'=>'All Issues','active'=>'Active','overdue'=>'Overdue','returned'=>'Returned'] as $k=>$lbl): ?>
    <a href="?filter=<?= $k ?>" class="btn <?= $filter===$k ? 'btn-primary' : 'btn-secondary' ?>"><?= $lbl ?></a>
    <?php endforeach; ?>
</div>

<div class="search-bar">
    <form method="GET" style="display:flex;gap:8px;flex:1;">
        <input type="hidden" name="filter" value="<?= htmlspecialchars($filter) ?>">
        <input type="text" name="s" placeholder="Search student or book..." value="<?= htmlspecialchars($search) ?>">
        <button type="submit" class="btn btn-primary">Search</button>
        <?php if ($search): ?><a href="?filter=<?= $filter ?>" class="btn btn-secondary">Clear</a><?php endif; ?>
    </form>
</div>

<div class="el-card">
    <div class="el-card-header">📋 Results (<?= count($issues) ?>)</div>
    <div class="p-0">
        <?php if ($issues): ?>
        <table class="el-table">
            <thead>
                <tr><th>#</th><th>Book</th><th>Student</th><th>Issued</th><th>Due Date</th><th>Returned</th><th>Fine</th><th>Status</th></tr>
            </thead>
            <tbody>
                <?php $n=1; foreach ($issues as $i): ?>
                <?php $overdue = ($i->status==='issued' && $i->days_overdue>0); ?>
                <tr <?= $overdue ? 'class="row-overdue"' : '' ?>>
                    <td><?= $n++ ?></td>
                    <td><?= htmlspecialchars($i->book_name) ?></td>
                    <td><?= htmlspecialchars($i->student_name) ?><br><small class="text-muted"><?= htmlspecialchars($i->sid) ?></small></td>
                    <td><?= date('d M Y', strtotime($i->issue_date)) ?></td>
                    <td><?= date('d M Y', strtotime($i->due_date)) ?></td>
                    <td><?= $i->return_date ? date('d M Y', strtotime($i->return_date)) : '<span class="text-muted">—</span>' ?></td>
                    <td>
                        <?php if ($i->fine_amount > 0): ?>
                        <span class="text-danger fw-bold">₨<?= number_format($i->fine_amount,0) ?></span>
                        <?= $i->fine_paid ? '<span class="badge badge-success" style="margin-left:4px;">Paid</span>' : '<span class="badge badge-danger" style="margin-left:4px;">Unpaid</span>' ?>
                        <?php else: ?>
                        <span class="text-muted">—</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($i->status==='returned'): ?>
                            <span class="badge badge-success">Returned</span>
                        <?php elseif ($overdue): ?>
                            <span class="badge badge-danger">Overdue</span>
                        <?php else: ?>
                            <span class="badge badge-info">Issued</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="no-data">No records found.</div>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
