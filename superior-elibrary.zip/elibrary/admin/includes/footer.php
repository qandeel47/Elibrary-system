</main>
</div><!-- end el-layout -->

<footer class="el-footer">
    © <?php echo date('Y'); ?> Superior University E-Library System &mdash; All Rights Reserved
</footer>

</body>
</html>
