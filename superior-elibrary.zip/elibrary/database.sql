-- Superior E-Library Management System
-- Database: elibrary

CREATE DATABASE IF NOT EXISTS elibrary;
USE elibrary;

-- ADMIN TABLE
CREATE TABLE IF NOT EXISTS tbl_admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    admin_id VARCHAR(50) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- STUDENTS TABLE
CREATE TABLE IF NOT EXISTS tbl_students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(50) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20),
    department VARCHAR(100),
    password VARCHAR(255) NOT NULL,
    status TINYINT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- CATEGORIES TABLE
CREATE TABLE IF NOT EXISTS tbl_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL,
    status TINYINT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- AUTHORS TABLE
CREATE TABLE IF NOT EXISTS tbl_authors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    author_name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- BOOKS TABLE
CREATE TABLE IF NOT EXISTS tbl_books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    book_name VARCHAR(200) NOT NULL,
    category_id INT NOT NULL,
    author_id INT NOT NULL,
    isbn VARCHAR(50) NOT NULL UNIQUE,
    book_image VARCHAR(255),
    total_qty INT DEFAULT 1,
    available_qty INT DEFAULT 1,
    ebook_file VARCHAR(255),
    description TEXT,
    status TINYINT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES tbl_categories(id),
    FOREIGN KEY (author_id) REFERENCES tbl_authors(id)
);

-- BOOK ISSUES TABLE
CREATE TABLE IF NOT EXISTS tbl_issues (
    id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT NOT NULL,
    student_id INT NOT NULL,
    issue_date DATE NOT NULL,
    due_date DATE NOT NULL,
    return_date DATE DEFAULT NULL,
    fine_amount DECIMAL(10,2) DEFAULT 0,
    fine_paid TINYINT DEFAULT 0,
    status ENUM('issued','returned','overdue') DEFAULT 'issued',
    issued_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (book_id) REFERENCES tbl_books(id),
    FOREIGN KEY (student_id) REFERENCES tbl_students(id)
);

-- EBOOK READS/DOWNLOADS LOG
CREATE TABLE IF NOT EXISTS tbl_ebook_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT NOT NULL,
    student_id INT NOT NULL,
    action ENUM('read','download') DEFAULT 'read',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (book_id) REFERENCES tbl_books(id),
    FOREIGN KEY (student_id) REFERENCES tbl_students(id)
);

-- FINE RATE SETTING
CREATE TABLE IF NOT EXISTS tbl_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value VARCHAR(255) NOT NULL
);

-- DEFAULT DATA
INSERT INTO tbl_settings (setting_key, setting_value) VALUES
('fine_per_day', '10'),
('loan_days', '14'),
('library_name', 'Superior University E-Library');

INSERT INTO tbl_categories (category_name, status) VALUES
('Computer Science', 1),
('Mathematics', 1),
('Physics', 1),
('Literature', 1),
('History', 1),
('Engineering', 1),
('Medical Sciences', 1),
('Business & Economics', 1);

INSERT INTO tbl_authors (author_name) VALUES
('Robert C. Martin'),
('Donald Knuth'),
('Dennis Ritchie'),
('Bjarne Stroustrup'),
('Andrew Tanenbaum');

-- Default admin: admin / admin123
INSERT INTO tbl_admin (admin_id, full_name, email, password) VALUES
('ADM001', 'System Administrator', 'admin@elibrary.edu', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');
