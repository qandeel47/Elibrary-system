<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Superior University E-Library</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            margin: 0;
            min-height: 100vh;
            background: linear-gradient(135deg, #341f42 0%, #4b2c5e 55%, #7a4e9e 100%);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            font-family: 'DM Sans', sans-serif;
        }

        .logo-top {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 40px;
        }

        .logo-top img {
            height: 56px;
            background: white;
            border-radius: 10px;
            padding: 5px;
        }

        .logo-top .lib-title {
            font-family: 'Playfair Display', serif;
            font-size: 26px;
            color: white;
            font-weight: 700;
        }

        .logo-top .lib-sub {
            font-size: 12px;
            color: rgba(255,255,255,0.65);
            margin-top: 2px;
        }

        .role-container {
            display: flex;
            gap: 24px;
            flex-wrap: wrap;
            justify-content: center;
        }

        .role-card {
            background: white;
            border-radius: 16px;
            padding: 40px 32px;
            width: 280px;
            text-align: center;
            box-shadow: 0 16px 48px rgba(0,0,0,0.25);
            transition: 0.3s;
        }

        .role-card:hover { transform: translateY(-6px); box-shadow: 0 24px 60px rgba(0,0,0,0.3); }

        .role-card .role-icon {
            width: 72px;
            height: 72px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 30px;
            margin: 0 auto 18px;
        }

        .role-card.admin-card .role-icon { background: #e8d5f5; }
        .role-card.student-card .role-icon { background: #d5f5e3; }

        .role-card h3 {
            font-family: 'Playfair Display', serif;
            font-size: 20px;
            color: #4b2c5e;
            margin-bottom: 8px;
        }

        .role-card p {
            font-size: 13px;
            color: #7a6b8a;
            margin-bottom: 24px;
            line-height: 1.6;
        }

        .role-btn {
            display: block;
            padding: 12px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            text-decoration: none;
            transition: 0.2s;
            margin-bottom: 10px;
        }

        .btn-admin   { background: #4b2c5e; color: white; }
        .btn-admin:hover { background: #341f42; color: white; }

        .btn-student { background: #27ae60; color: white; }
        .btn-student:hover { background: #219a52; color: white; }

        .btn-outline {
            border: 1.5px solid #4b2c5e;
            color: #4b2c5e;
            background: transparent;
            padding: 10px;
        }

        .btn-outline:hover { background: #4b2c5e; color: white; }

        .footer-text {
            color: rgba(255,255,255,0.4);
            font-size: 12px;
            margin-top: 36px;
        }
    </style>
</head>
<body>

<div class="logo-top">
    <img src="assets/img/logo.png" alt="Superior University">
    <div>
        <div class="lib-title">Superior University E-Library</div>
        <div class="lib-sub">Knowledge is the key to every door</div>
    </div>
</div>

<div class="role-container">

    <!-- Admin Card -->
    <div class="role-card admin-card">
        <div class="role-icon">🛡️</div>
        <h3>Administrator</h3>
        <p>Manage books, students, issues, returns, fines and all library operations.</p>
        <a href="admin/login.php" class="role-btn btn-admin">Admin Login</a>
        <a href="admin/register.php" class="role-btn btn-outline">Create Admin Account</a>
    </div>

    <!-- Student Card -->
    <div class="role-card student-card">
        <div class="role-icon">📚</div>
        <h3>Student / User</h3>
        <p>Browse, read and download e-books, view your issued books and fine status.</p>
        <a href="student/login.php" class="role-btn btn-student">Student Login</a>
        
    </div>

</div>

<div class="footer-text">© <?php echo date('Y'); ?> Superior University E-Library System</div>

</body>
</html>
